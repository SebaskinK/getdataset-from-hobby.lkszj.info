#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从已分类 CSV 重新生成受控词总表与各大类映射文档。"""
import csv
from collections import Counter, defaultdict

SRC = '兴趣爱好大全_已分类.csv'
rows = [r for r in csv.DictReader(open(SRC, encoding='utf-8-sig')) if r['类别'] != '其他']

DOCS = {
    '手法/运动': None,
    '创作/美术': None,
    '游戏/桌游': '游戏桌游_受控词映射.md',
    '收藏/装备': '收藏装备_受控词映射.md',
    '二次元/同人': '二次元同人_受控词映射.md',
    '阅读/知识': '阅读知识_受控词映射.md',
    '生活/饮食': '生活饮食_受控词映射.md',
    '乐器/音乐': '乐器音乐_受控词映射.md',
    '视听/休闲': None,
    '数码/科技': '数码科技_受控词映射.md',
    '玄学/身心': '玄学身心_受控词映射.md',
    '社交/职场/钱': '社交职场钱_受控词映射.md',
    '成人向': '成人向_受控词映射.md',
}

by_cat = defaultdict(lambda: defaultdict(Counter))   # cat -> sub -> term -> n
alias = defaultdict(Counter)                        # (cat, sub, term) -> 规范名 -> n
for r in rows:
    cat, sub, term, raw = r['类别'], r['子类'], r['标准兴趣'], r['规范名']
    by_cat[cat][sub][term] += 1
    alias[(cat, sub, term)][raw] += 1

cat_n = Counter(r['类别'] for r in rows)
cat_terms = {c: len({t for s in by_cat[c].values() for t in s}) for c in by_cat}
cat_subs = {c: len(by_cat[c]) for c in by_cat}
cat_order = [c for c, _ in cat_n.most_common()]

def sorted_terms(d):
    return sorted(d.items(), key=lambda kv: (-kv[1], kv[0]))

# ---- 总表 ----
lines = ['', '# 受控词总表（2026-11-19 第十一轮清理后）', '']
for cat in cat_order:
    lines.append(f'# {cat}（{cat_n[cat]} 条，{cat_subs[cat]} 个子类，{cat_terms[cat]} 个受控词）')
    lines.append('')
    for sub, terms in sorted(by_cat[cat].items(),
                             key=lambda kv: (-sum(kv[1].values()), kv[0])):
        n_sub = sum(terms.values())
        lines.append(f'## {sub}（{n_sub} 条，{len(terms)} 词）')
        lines.append('、'.join(t for t, _ in sorted_terms(terms)))
        lines.append('')
with open('兴趣爱好分类_受控词总表.md', 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines).rstrip() + '\n')

# ---- 各大类映射 ----
for cat, fn in DOCS.items():
    if not fn:
        continue
    out = [f'# {cat}：受控词 ← 来源写法映射', '',
           '说明：规范名 = 原始兴趣名去空格/标点/表情、合并同义写法后的结果。',
           f'口径：{cat_n[cat]} 条，{cat_terms[cat]} 个受控词。', '',
           '> 本文件由 `classify_hobbies.py` 重建后自动汇总；受控词按子类排列。', '']
    for sub, terms in sorted(by_cat[cat].items(),
                             key=lambda kv: (-sum(kv[1].values()), kv[0])):
        out.append(f'## {sub}（{sum(terms.values())} 条）')
        out.append('')
        for term, n in sorted_terms(terms):
            al = alias[(cat, sub, term)]
            out.append(f'### {term}（{n} 条，{len(al)} 种写法）')
            parts = []
            for a, k in sorted(al.items(), key=lambda kv: (-kv[1], kv[0])):
                parts.append(f'{a}×{k}' if k > 1 else a)
            out.append('、'.join(parts))
            out.append('')
    with open(fn, 'w', encoding='utf-8') as f:
        f.write('\n'.join(out).rstrip() + '\n')

print('已生成总表与 10 份映射文档')
print('大类数', len(cat_order), '受控词总数', sum(cat_terms.values()))
