#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""筛选当前受控词表中：句子/短语类、过长、含义近似的受控词。只做分析，不改数据。"""
import csv, re, unicodedata
from collections import Counter, defaultdict

SRC = '兴趣爱好大全_已分类.csv'

rows = []
with open(SRC, newline='', encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        if r['类别'] != '其他':
            rows.append(r)

terms = defaultdict(Counter)   # (大类, 子类) -> term counts
for r in rows:
    terms[(r['类别'], r['子类'])][r['标准兴趣']] += 1

all_terms = []
for (cat, sub), c in terms.items():
    for t, n in c.items():
        all_terms.append((cat, sub, t, n))

print('总行数', len(rows), '受控词条目', len(all_terms), '唯一词', len({t for _,_,t,_ in all_terms}))

# ---------- 1. 句子/短语类 ----------
PUNCT = set('，。！？；：、“”‘’《》【】…')
FUNC = ['我的爱好', '我喜欢', '我的', '我喜欢', '喜欢', '各种', '各种各样', '之类', '等等',
        '比如', '例如', '还有', '以及', '或者', '包括', '最好', '一起', '一个人', '别人',
        '自己', '让我', '令人', '感觉', '时候', '因为', '但是', '而且', '然后', '就是',
        '真的', '非常', '可以', '能够', '一些', '一切', '所有', '任何', '不同', '各类',
        '好多', '很多', '主要是', '主要是', '算是', '属于', '之类', '什么的', '吧', '呢',
        '啊', '呀', '哈哈', '嘻嘻', '完了', '就行', '就好', '也不错']
LEAD_VERB = ('玩', '看', '听', '买', '逛', '吃', '喝', '做', '找', '收', '学', '打', '刷',
             '研究', '体验', '尝试', '整理', '收集', '收藏', '分享', '给', '和', '在', '把')

def zh_len(s):
    return len(re.sub(r'[^\u4e00-\u9fff]', '', s))

def has_punct(s):
    return any(ch in PUNCT for ch in s) or ' ' in s.strip()

sent = []
for cat, sub, t, n in all_terms:
    reasons = []
    if has_punct(t):
        reasons.append('含标点/空格')
    hit = [w for w in FUNC if w in t]
    if hit:
        reasons.append('含' + '/'.join(sorted(set(hit))[:3]))
    L = len(t)
    if L >= 10:
        reasons.append(f'长度{L}')
    elif L >= 7 and t.startswith(LEAD_VERB):
        reasons.append(f'动词开头且长{L}')
    if re.search(r'[0-9]{2,}', t):
        reasons.append('含长数字')
    if reasons:
        sent.append((L, cat, sub, t, n, ','.join(reasons)))
sent.sort(key=lambda x: (-x[0], x[1], x[2]))

# ---------- 2. 过长（>=7 字，未进句子类的也算） ----------
longs = [(len(t), cat, sub, t, n) for cat, sub, t, n in all_terms if len(t) >= 7]
longs.sort(key=lambda x: (-x[0], x[1], x[2]))

# ---------- 3. 近似 ----------
def norm(s):
    s = unicodedata.normalize('NFKC', s).lower()
    return re.sub(r'[\s\-_·:：/／()（）·、,，.。]', '', s)

groups = defaultdict(list)
for cat, sub, t, n in all_terms:
    groups[cat].append((sub, t, n))

# 3a 归一化后相同
dup_norm = defaultdict(list)
for cat, sub, t, n in all_terms:
    dup_norm[(cat, norm(t))].append((sub, t, n))
dup_norm = {k: v for k, v in dup_norm.items() if len({x[1] for x in v}) > 1}

# 3b 同大类内包含关系
contain = []
for cat, lst in groups.items():
    ts = sorted({t for _, t, _ in lst}, key=len)
    for i, a in enumerate(ts):
        for b in ts:
            if a != b and a in b and len(b) - len(a) <= 4 and norm(a) != norm(b):
                contain.append((cat, a, b))
contain = sorted(set(contain))

# 3c 编辑距离 <=1
def lev1(a, b):
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) == 1
    if len(a) > len(b):
        a, b = b, a
    i = j = 0; diff = 0
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1; j += 1
        else:
            diff += 1; j += 1
            if diff > 1:
                return False
    return True
near = []
for cat, lst in groups.items():
    ts = sorted({t for _, t, _ in lst})
    for i in range(len(ts)):
        for j in range(i + 1, len(ts)):
            if len(ts[i]) >= 3 and lev1(norm(ts[i]), norm(ts[j])):
                near.append((cat, ts[i], ts[j]))

with open('_term_analysis.txt', 'w', encoding='utf-8') as f:
    f.write(f'== 1. 句子/短语类 {len(sent)} ==\n')
    for L, cat, sub, t, n, why in sent:
        f.write(f'{cat}\t{sub}\t{t}\t{n}\t{why}\n')
    f.write(f'\n== 2. 过长(>=7) {len(longs)} ==\n')
    for L, cat, sub, t, n in longs:
        f.write(f'{L}\t{cat}\t{sub}\t{t}\t{n}\n')
    f.write(f'\n== 3a 归一化重复 {len(dup_norm)} ==\n')
    for (cat, k), v in sorted(dup_norm.items()):
        f.write(f'{cat}\t{k}\t{v}\n')
    f.write(f'\n== 3b 包含关系 {len(contain)} ==\n')
    for cat, a, b in contain:
        f.write(f'{cat}\t{a}\t⊂\t{b}\n')
    f.write(f'\n== 3c 编辑距离1 {len(near)} ==\n')
    for cat, a, b in near:
        f.write(f'{cat}\t{a}\t~=\t{b}\n')
print('sent', len(sent), 'long', len(longs), 'dupnorm', len(dup_norm), 'contain', len(contain), 'near', len(near))
